
let valueInputSum = 0;

onClickButton = () => {
  valueInputSum++;
  console.log(valueInputSum);
}
onClickButtonВdecrement = () =>{
valueInputSum--;
console.log(valueInputSum);
}
 
 