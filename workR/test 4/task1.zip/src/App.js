import Header from './Header';
import './App.scss';
// Реализовать компонент header в который пропсами передаются параметры: ссылка на изображение, название, кто создатель. Вызвать его 3 раза с разными пропсами.

function App() {

  return (
    <div className="App">
      <Header url = "https://yarcube.ru/upload/iblock/29e/samye-vkusnye-knigi-k-novomu-godu-novye-prazdnichnye-retsepty.jpg"/>
      <Header name = "Text1"/>
      <Header  author = "NoName"/>
    </div>
  );
}

export default App;
