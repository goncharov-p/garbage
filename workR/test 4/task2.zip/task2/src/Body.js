import React from "react";

function Body(props){
    return (
            props.children 
    )
}
export default Body;