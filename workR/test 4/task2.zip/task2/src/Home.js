import React from "react";
import { 
    Routes, 
    Route, 
    useNavigate 
    } from 'react-router-dom';
import { useState } from "react/cjs/react.development";
import Company from "./Company";
    

function Home() {
   

    return(
        <div>Home</div>
    );
}
export default Home;