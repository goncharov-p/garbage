import React, { useState  } from 'react';
import Footer from './Footer';
import Body from './Body';
import Header from './Header';
import './App.scss';

function App() {
 

  return (
    <div>
      <Header />
      <Body />
      <Footer />
    </div>
  );
}

export default App;
