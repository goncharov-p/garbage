import React from "react";

function Footer(){
    return (
        <div>
            <h6>Footer</h6>
        </div>
    )
}
export default Footer;