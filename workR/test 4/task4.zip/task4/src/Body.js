import React from "react";

function Body(){
    return (
        <div>
            <h6>Body</h6>
        </div>
    )
}
export default Body;