import logo from './logo.svg';
import Test from './Test';
import './App.scss';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <p>Гончаров Павел</p>
      </header>
      <body style={{background:'red'}}>body</body>
      <footer style={{background:'green'}}>footer</footer>
    </div>
  );
}

export default App;
