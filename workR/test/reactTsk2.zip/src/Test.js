import React from "react";

class Test extends React.Component {
render(){
    return<p>Test component</p>
}
}
export default Test;