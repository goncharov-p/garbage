import logo from './logo.svg';
import Test from './Test';
import './App.scss';

function App() {
  const Test = <div>text text</div>;
  
  return (
    <div className="App">
      <header className="App-header">
        <p>Гончаров Павел</p>
      </header>
      <body style={{background:'red',fontSize:'20px',height:'40vh'}}>body
        {Test}
        {Test}
        {Test}
      </body>
      <footer style={{background:'green',fontSize:'40px'}}>footer</footer>
    </div>
  );
}

export default App;
