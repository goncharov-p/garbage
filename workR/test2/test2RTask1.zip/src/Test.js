import React from "react";
import logoImg from './logo.svg';


function Test({name}){
    return (
        <div>
            <h1>{name}</h1>
        </div>
    )
}
export default Test;