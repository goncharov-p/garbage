import React from "react";
import logoImg from './logo.svg';


function Test({flag}){
    return (
        <>
        {flag ? <h1>Text for block 1</h1>
        :<h1>Text for block 2</h1>}
        </>
    )
}
export default Test;