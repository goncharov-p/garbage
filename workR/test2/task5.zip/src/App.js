import logo from './logo.svg';
import Test from './Test';
import Company from './Company';
import './App.scss';

function App() {
 
  const companies = [
    {
      name:'arr1',
      owner:'Ivan ivanov'
    },
    {
      name:'arr1',
      owner:'Petr ivanov'
    },
  ];

  const comp = [
    {
      name:'arr2',
      owner:'Ivan'
    },
    {
      name:'arr2',
      owner:'Petr'
    },
  ];

  const compres = [
    {
      name:'arr3',
      owner:'Iv'
    },
    {
      name:'arr3',
      owner:'Pe'
    },
  ];
  return (
    <div className="App">
      {
        companies.map((value,index) =>  <Company key = {`company-${index}`} company = {value}/>)
        
      }
      {
        comp.map((value,index) =>  <Company key = {`company-${index}`} company = {value}/>)
        
      }
      {
        compres.map((value,index) =>  <Company key = {`company-${index}`} company = {value}/>)
        
      }
     
    </div>
  );
}

export default App;
