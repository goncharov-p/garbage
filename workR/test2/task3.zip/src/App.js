import logo from './logo.svg';
import Test from './Test';
import Company from './Company';
import './App.scss';

function App() {
  const prop = {flag:false}
 
  return (
    <div className="App">
      <Test prop/>
  
    </div>
  );
}

export default App;
