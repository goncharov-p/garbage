import React from "react";
import logoImg from './logo.svg';


function Test(props){
    return (
        <div>
             {props.children}
        </div>
    )
}
export default Test;