import logo from './logo.svg';
import Test from './Test';
import Company from './Company';
import './App.scss';

function App() {
 

  return (
    <div className="App">
    <Test>
      <h1>Первый</h1>
    </Test>
    <Test>
      <h1>Второй</h1>
    </Test>
    <Test>
      <h1>Третий</h1>
    </Test>
     
    </div>
  );
}

export default App;
