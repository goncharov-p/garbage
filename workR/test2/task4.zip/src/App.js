import logo from './logo.svg';
import Test from './Test';
import Company from './Company';
import './App.scss';

function App() {
 
  const companies = [
    {
      name:'Test1',
      owner:'Ivan ivanov'
    },
    {
      name:'Test1',
      owner:'Petr ivanov'
    },
    {
      name:'Test1',
      owner:'Petr Petrov'
    }
  ];
  return (
    <div className="App">
      {
        companies.map((value,index) =>  <Company key = {`company-${index}`} company = {value}/>)
      }
     
    </div>
  );
}

export default App;
