import logo from './logo.svg';
import Test from './Test';
import Company from './Company';
import Header from './Header';
import './App.scss';

function App() {

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
      <Header url = "https://yarcube.ru/upload/iblock/29e/samye-vkusnye-knigi-k-novomu-godu-novye-prazdnichnye-retsepty.jpg" name = "Text1" author = "NoName"/>

    </div>
  );
}

export default App;
