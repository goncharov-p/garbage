import React, { useState  } from 'react';
import logo from './logo.svg';
import Test from './Test';
import Company from './Company';
import './App.scss';

function App() {

  const [flag, setFlag] = useState()
  return (
    <div className="App">
      <button onClick={()=> setFlag(!flag)}>Кнопка</button>
      {flag? <div>One</div> : <div>Two</div>}
      </div>
    );
}

export default App;
