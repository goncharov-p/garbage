import React, { useState  } from 'react';
import ComponentTestOne from "./ComponentTestOne"
import ComponentTestTwo from "./ComponentTestTwo"
import logoImg from './logo.svg';


function  Test() {

  const [flag, setFlag] = useState(false)
  return (
    <div className="App">
      <ComponentTestOne flag/>
      <ComponentTestTwo flag/>
      {flag ? <div> Нажата кнопка в компоненте 1</div> :  <div> Нажата кнопка второго компонента</div> }
      </div>
    );
}
export default Test;