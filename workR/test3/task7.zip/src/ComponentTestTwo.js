import React from 'react';

function  ComponentTestTwo({flag}) {
const func=(flag)=>{
    flag = false;
    console.log(flag);
}
  return (
    <button onClick={()=> func(flag)}>Кнопка #2</button>
    );
}
export default ComponentTestTwo;