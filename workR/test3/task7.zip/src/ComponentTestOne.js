import React from 'react';

function  ComponentTestOne({setFlag,flag}) {
    const func=(flag)=>{
        flag = true;  
        console.log(flag);
    }
  return (
    <button onClick={()=> func(flag)}>Кнопка #1</button>
    );
}
export default ComponentTestOne;