import React, { useState  } from 'react';
import logo from './logo.svg';
import Test from './Test';
import Company from './Company';
import './App.scss';

function App() {
 const handleSubmit = (e) => {
  e.preventDefault();
  const formData = new FormData(e.target);
  console.log(formData.get('text'));
  console.log(formData.get('text2'));
 };
  
  return (
   <form onSubmit={handleSubmit}>
     <input type='text' id='text' name='text'/>
     <input type='text' id='text2' name='text2' />
     <button >Button</button>
   </form>
  );
}

export default App;
