import React, { useState  } from 'react';
import logo from './logo.svg';
import Test from './Test';
import Company from './Company';
import './App.scss';

function App() {
 
  const style = {
    backgroundColor: 'red',
  }
  const styleNext = {
    backgroundColor: 'blue',
  }
  const [taskStyle, setTaskStyle] = useState()
  return (
    <div className="App">
      <button onClick={()=> setTaskStyle(!taskStyle)}>Кнопка</button>
      {taskStyle ? <div style={style}>1</div> : <div style={styleNext}>2</div>}
      </div>
    );

}

export default App;
