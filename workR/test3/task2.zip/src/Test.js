import React from "react";
import logoImg from './logo.svg';


class Test extends React.Component{
    constructor(props) {
        super();

        this.state ={
            flag:true
        }
    }
    render () {
        console.log(this.state.flag );
        return(
            <button onClick={() => this.setState({flag: !this.state.flag})}>button</button>
           
        )
    }
}
export default Test;