import React from 'react';

function  ComponentTestTwo() {
 
  return (
    <div>Component 2</div>
    );
}
export default ComponentTestTwo;