import React, { useState  } from 'react';
import ComponentTestOne from "./ComponentTestOne"
import ComponentTestTwo from "./ComponentTestTwo"
import logoImg from './logo.svg';


function  Test() {

  const [flag, setFlag] = useState(false)
  return (
    <div className="App">
      <button onClick={()=> setFlag(!flag)}>Кнопка</button>
      {flag ?   <ComponentTestOne /> :  <ComponentTestTwo /> }
      </div>
    );
}
export default Test;