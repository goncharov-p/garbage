const express = require('express');
const _ = require('underscore');
const app = express();


app.get('/rest',(req,res)=>{
  let t = req.query;
  let iName = t.fullName;
  const arr = iName.split(" ");
  const nameA = _.first(arr[0]);
  const nameB = _.first(arr[1]);
  const result = nameA + nameB;
  console.log(result);
});

app.listen(8000, () => {
  console.log('Example app listening on port 8000!')
});