let res=0;

fun=()=>{
  console.log(res++);
}

fun2=()=>{console.log(res--);}