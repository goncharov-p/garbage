const arr = [2,4,6,4,5,4];

const result = _.uniq(arr);

console.log(result);

