const arr = [2,8,8,78,45,788,5];
const num = 3;

const result = _.chunk(arr,num);

console.log(result);