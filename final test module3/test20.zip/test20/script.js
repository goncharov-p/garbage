let arr =['var','hello','result','fun','textr'];

res  = _.sortBy(arr, (num) => num.length);

console.log(res);