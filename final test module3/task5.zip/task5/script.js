const arr = [];
let result = "";
const fun =(obj) => {
    for(let i = 0; i <10; i++){ 
        result = result + "x";
        arr.push(result);
    //arr.push(result);
}}
fun(arr);
console.log(arr);