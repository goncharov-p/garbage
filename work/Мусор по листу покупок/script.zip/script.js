let allPurchases = [];
let valueInput = '';
let valueInputSum = '';
let input1 = null;
let input2 = null;
let activeEditTask = null;
const link = 'http://localhost:8000';

const getTasks = async() => {
  console.log("sadf")
    const resp = await fetch(`${link}/allTasks`, {
      method: 'GET'
    });
    let result = await resp.json();
    allPurchases = result.data;
    console.log("allPurchases")
    render();
   
  }

window.onload = async function init () {
    input1 = document.getElementById('add-task');
    input2 = document.getElementById('add-task-sum');
    input1.addEventListener('change', updateValue);
    input2.addEventListener('change', updateValueSum);
    
    getTasks();

}

updateValue = (event) => {
    valueInput = event.target.value;   
}

updateValueSum = (event) => {
  valueInputSum = event.target.value;
}

onClickButton = async() => {
    if (valueInput && valueInputSum) {
      const resp = await fetch(`${link}/createTask`, {
        method: 'POST',
        headers: {
          'Content-Type':'application/json;charset=utf-8',
          'Access-Control-Allow-Origin':'*'
        },
        body: JSON.stringify({
            directionOfFlow: valueInput,
            sum: valueInputSum, 
        })
      })
      
      const result = await resp.json()
      .then((resp) => { 
        allPurchases.push(resp);
        valueInput = '';
        valueInputSum = '';
        input1.value = '';
        input2.value = '';
        render();
      });
    } else {
      alert('Поле не может быть пустым')
    }
    console.log(allPurchases)
  }

  render =  () => {
    console.log("render");
    const content = document.getElementById('content-page');
  
    while(content.firstChild){ 
      content.removeChild(content.firstChild); 
    }
      allPurchases
      .sort((a,b)=>{if (a.isCheck === b.isCheck) return 0;
        return (a.isCheck > b.isCheck) ? 1 : -1})
      .map((item, index) => {
      const container = document.createElement('div'); 
      container.id = `task-${index}`;
      container.className = 'task-container';
  
      if(item._id === activeEditTask) {
     
       const inputTask = document.createElement('input');
       inputTask.type = 'text';
       console.log(inputTask)
       inputTask.value = item.text;
       inputTask.addEventListener('change',updateTaskText);
       inputTask.addEventListener('blur', doneEditTask);
       container.appendChild(inputTask)
     } else{
       const text = document.createElement('p');
       text.innerText = item.text
       container.appendChild(text);
        
     }
     if(!item.isCheck) { 
       if (item._id === activeEditTask) {
         const imageDone = document.createElement('img');
         imageDone.src = 'images/check-mark.png';
         imageDone.onclick = function () {
           doneEditTask();
         };
         container.appendChild(imageDone);
       } else {
         const imageEdit = document.createElement('img');
         imageEdit.src = 'images/kar.svg'
         imageEdit.onclick = function () {
           activeEditTask = item._id;
           render();
         };
         container.appendChild(imageEdit)
       }
   
      }
       
      const imageDelete = document.createElement('img');
      imageDelete.src = 'images/urn.svg';
      imageDelete.onclick = function () {
        onDeleteTask(item._id);
      }
      container.appendChild(imageDelete);
      content.appendChild(container);
    });  
  }

  onDeleteTask = async (index) => {
    const resp = await fetch(`${link}/deleteTask?id=${index}`, {
      method: 'DELETE',
    });
    getTasks();
  }

  updateTaskText = async (event) => {
    const resp = await fetch(`${link}/updateTask`, {
      method: 'PATCH',
      headers: {
        'Content-Type':'application/json;charset=utf-8',
        'Access-Control-Allow-Origin':'*'
      },
      body: JSON.stringify({
        id: activeEditTask,
        text: event.target.value,     
      })
    });
    getTasks();
  }

  doneEditTask = () => {
    activeEditTask = null;
    render();
  }